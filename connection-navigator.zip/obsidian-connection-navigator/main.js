/*
Connection Navigator Plugin for Obsidian
Double-click on canvas nodes to view their connections in a popup panel.
Click on connections to navigate to linked nodes.
*/

const { Plugin, Modal, setIcon } = require('obsidian');

class ConnectionModal extends Modal {
    constructor(app, nodeData, canvasData, canvasView) {
        super(app);
        this.nodeData = nodeData;
        this.canvasData = canvasData;
        this.canvasView = canvasView;
    }

    onOpen() {
        const { contentEl } = this;
        contentEl.empty();
        contentEl.addClass('connection-navigator-modal');

        // Header
        const header = contentEl.createDiv({ cls: 'connection-header' });
        header.createEl('h2', { text: 'Node Connections' });
        
        // Node info
        const nodeInfo = contentEl.createDiv({ cls: 'node-info' });
        const nodeLabel = this.getNodeLabel(this.nodeData);
        nodeInfo.createEl('div', { 
            text: nodeLabel, 
            cls: 'node-label' 
        });

        // Get connections
        const connections = this.getConnections();
        
        // Connections section
        const connectionsSection = contentEl.createDiv({ cls: 'connections-section' });
        
        if (connections.length === 0) {
            connectionsSection.createEl('div', { 
                text: 'No connections found', 
                cls: 'no-connections' 
            });
        } else {
            // Stats
            const incoming = connections.filter(c => c.direction === 'incoming');
            const outgoing = connections.filter(c => c.direction === 'outgoing');
            
            const stats = connectionsSection.createDiv({ cls: 'connection-stats' });
            stats.createEl('span', { text: `${connections.length} total connections` });
            stats.createEl('span', { text: ` • ${incoming.length} incoming • ${outgoing.length} outgoing`, cls: 'stats-detail' });

            // Connection list
            const list = connectionsSection.createDiv({ cls: 'connection-list' });
            
            // Group by direction
            if (incoming.length > 0) {
                const incomingHeader = list.createDiv({ cls: 'direction-header' });
                incomingHeader.createEl('span', { text: '← Incoming', cls: 'direction-label incoming' });
                
                incoming.forEach(conn => this.createConnectionItem(list, conn));
            }
            
            if (outgoing.length > 0) {
                const outgoingHeader = list.createDiv({ cls: 'direction-header' });
                outgoingHeader.createEl('span', { text: '→ Outgoing', cls: 'direction-label outgoing' });
                
                outgoing.forEach(conn => this.createConnectionItem(list, conn));
            }
        }
    }

    createConnectionItem(container, conn) {
        const item = container.createDiv({ cls: 'connection-item' });
        
        // Direction indicator
        const indicator = item.createDiv({ cls: `direction-indicator ${conn.direction}` });
        indicator.textContent = conn.direction === 'incoming' ? '←' : '→';
        
        // Content
        const content = item.createDiv({ cls: 'connection-content' });
        content.createEl('div', { text: conn.targetLabel, cls: 'target-name' });
        
        if (conn.edgeLabel) {
            content.createEl('div', { text: `"${conn.edgeLabel}"`, cls: 'edge-label' });
        }

        // Click to navigate
        item.addEventListener('click', () => {
            this.navigateToNode(conn.targetId);
        });
    }

    getNodeLabel(node) {
        if (node.text) {
            // Truncate long text
            const text = node.text.replace(/\n/g, ' ').substring(0, 100);
            return text + (node.text.length > 100 ? '...' : '');
        }
        if (node.file) {
            return '📄 ' + node.file;
        }
        if (node.url) {
            return '🔗 ' + node.url;
        }
        return 'Untitled Node';
    }

    getConnections() {
        const connections = [];
        const edges = this.canvasData.edges || [];
        const nodes = this.canvasData.nodes || [];
        const nodeId = this.nodeData.id;

        edges.forEach(edge => {
            if (edge.fromNode === nodeId) {
                const targetNode = nodes.find(n => n.id === edge.toNode);
                if (targetNode) {
                    connections.push({
                        direction: 'outgoing',
                        targetId: edge.toNode,
                        targetLabel: this.getNodeLabel(targetNode),
                        targetNode: targetNode,
                        edgeLabel: edge.label || ''
                    });
                }
            } else if (edge.toNode === nodeId) {
                const sourceNode = nodes.find(n => n.id === edge.fromNode);
                if (sourceNode) {
                    connections.push({
                        direction: 'incoming',
                        targetId: edge.fromNode,
                        targetLabel: this.getNodeLabel(sourceNode),
                        targetNode: sourceNode,
                        edgeLabel: edge.label || ''
                    });
                }
            }
        });

        return connections;
    }

    navigateToNode(targetId) {
        // Close modal
        this.close();

        // Find the canvas and navigate to node
        if (this.canvasView && this.canvasView.canvas) {
            const canvas = this.canvasView.canvas;
            const targetNode = canvas.nodes.get(targetId);
            
            if (targetNode) {
                // Deselect all
                canvas.deselectAll();
                
                // Select target node
                canvas.select(targetNode);
                
                // Center view on node
                canvas.zoomToSelection();
            }
        }
    }

    onClose() {
        const { contentEl } = this;
        contentEl.empty();
    }
}

class ConnectionNavigatorPlugin extends Plugin {
    async onload() {
        console.log('Loading Connection Navigator plugin');

        // Add styles
        this.addStyles();

        // Register event for canvas
        this.registerEvent(
            this.app.workspace.on('active-leaf-change', (leaf) => {
                if (leaf?.view?.getViewType() === 'canvas') {
                    this.setupCanvasListeners(leaf.view);
                }
            })
        );

        // Setup for already open canvas
        const activeLeaf = this.app.workspace.activeLeaf;
        if (activeLeaf?.view?.getViewType() === 'canvas') {
            this.setupCanvasListeners(activeLeaf.view);
        }

        // Add command to show connections for selected node
        this.addCommand({
            id: 'show-node-connections',
            name: 'Show connections for selected node',
            checkCallback: (checking) => {
                const activeLeaf = this.app.workspace.activeLeaf;
                if (activeLeaf?.view?.getViewType() === 'canvas') {
                    const canvas = activeLeaf.view.canvas;
                    const selection = canvas?.selection;
                    if (selection?.size === 1) {
                        if (!checking) {
                            const selectedNode = selection.values().next().value;
                            this.showConnections(selectedNode, activeLeaf.view);
                        }
                        return true;
                    }
                }
                return false;
            }
        });
    }

    setupCanvasListeners(canvasView) {
        if (!canvasView?.canvas) return;

        const canvas = canvasView.canvas;
        const containerEl = canvas.wrapperEl || canvasView.contentEl;

        if (!containerEl) return;

        // Remove existing listener if any
        if (this.dblClickHandler) {
            containerEl.removeEventListener('dblclick', this.dblClickHandler);
        }

        // Add double-click listener
        this.dblClickHandler = (evt) => {
            // Find if we clicked on a node
            const target = evt.target;
            let nodeEl = target.closest('.canvas-node');
            
            if (nodeEl) {
                evt.preventDefault();
                evt.stopPropagation();
                
                // Get node ID from element
                const nodeId = nodeEl.dataset.id;
                if (nodeId) {
                    const node = canvas.nodes.get(nodeId);
                    if (node) {
                        this.showConnections(node, canvasView);
                    }
                }
            }
        };

        containerEl.addEventListener('dblclick', this.dblClickHandler, true);
    }

    showConnections(node, canvasView) {
        if (!node || !canvasView?.canvas) return;

        // Get canvas data
        const canvas = canvasView.canvas;
        const canvasData = {
            nodes: Array.from(canvas.nodes.values()).map(n => ({
                id: n.id,
                text: n.text || n.unknownData?.text,
                file: n.file || n.unknownData?.file,
                url: n.url || n.unknownData?.url,
                type: n.unknownData?.type || 'text'
            })),
            edges: Array.from(canvas.edges.values()).map(e => ({
                id: e.id,
                fromNode: e.from?.node?.id,
                toNode: e.to?.node?.id,
                label: e.label || e.unknownData?.label
            }))
        };

        const nodeData = {
            id: node.id,
            text: node.text || node.unknownData?.text,
            file: node.file || node.unknownData?.file,
            url: node.url || node.unknownData?.url
        };

        const modal = new ConnectionModal(this.app, nodeData, canvasData, canvasView);
        modal.open();
    }

    addStyles() {
        const style = document.createElement('style');
        style.id = 'connection-navigator-styles';
        style.textContent = `
            .connection-navigator-modal {
                padding: 20px;
                max-width: 500px;
            }

            .connection-navigator-modal .connection-header {
                border-bottom: 1px solid var(--background-modifier-border);
                padding-bottom: 10px;
                margin-bottom: 15px;
            }

            .connection-navigator-modal .connection-header h2 {
                margin: 0;
                font-size: 1.2em;
                color: var(--text-accent);
            }

            .connection-navigator-modal .node-info {
                background: var(--background-secondary);
                padding: 12px;
                border-radius: 6px;
                margin-bottom: 15px;
            }

            .connection-navigator-modal .node-label {
                font-size: 0.95em;
                color: var(--text-normal);
                word-break: break-word;
            }

            .connection-navigator-modal .connections-section {
                max-height: 400px;
                overflow-y: auto;
            }

            .connection-navigator-modal .connection-stats {
                font-size: 0.85em;
                color: var(--text-muted);
                margin-bottom: 15px;
            }

            .connection-navigator-modal .stats-detail {
                color: var(--text-faint);
            }

            .connection-navigator-modal .direction-header {
                margin-top: 15px;
                margin-bottom: 8px;
            }

            .connection-navigator-modal .direction-label {
                font-size: 0.85em;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            .connection-navigator-modal .direction-label.incoming {
                color: var(--color-cyan);
            }

            .connection-navigator-modal .direction-label.outgoing {
                color: var(--color-orange);
            }

            .connection-navigator-modal .connection-list {
                display: flex;
                flex-direction: column;
                gap: 6px;
            }

            .connection-navigator-modal .connection-item {
                display: flex;
                align-items: flex-start;
                gap: 10px;
                padding: 10px 12px;
                background: var(--background-secondary);
                border-radius: 6px;
                cursor: pointer;
                transition: background 0.15s, transform 0.15s;
                border: 1px solid transparent;
            }

            .connection-navigator-modal .connection-item:hover {
                background: var(--background-modifier-hover);
                border-color: var(--background-modifier-border);
                transform: translateX(2px);
            }

            .connection-navigator-modal .direction-indicator {
                font-size: 1.1em;
                min-width: 20px;
                text-align: center;
            }

            .connection-navigator-modal .direction-indicator.incoming {
                color: var(--color-cyan);
            }

            .connection-navigator-modal .direction-indicator.outgoing {
                color: var(--color-orange);
            }

            .connection-navigator-modal .connection-content {
                flex: 1;
                min-width: 0;
            }

            .connection-navigator-modal .target-name {
                font-size: 0.95em;
                color: var(--text-accent);
                word-break: break-word;
            }

            .connection-navigator-modal .edge-label {
                font-size: 0.85em;
                color: var(--text-muted);
                font-style: italic;
                margin-top: 4px;
            }

            .connection-navigator-modal .no-connections {
                text-align: center;
                color: var(--text-muted);
                padding: 30px;
                font-style: italic;
            }
        `;
        document.head.appendChild(style);
    }

    onunload() {
        console.log('Unloading Connection Navigator plugin');
        
        // Remove styles
        const style = document.getElementById('connection-navigator-styles');
        if (style) {
            style.remove();
        }
    }
}

module.exports = ConnectionNavigatorPlugin;
