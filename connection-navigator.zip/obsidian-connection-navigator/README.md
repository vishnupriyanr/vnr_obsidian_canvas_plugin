# Connection Navigator Plugin for Obsidian

A simple plugin that lets you **double-click on canvas nodes** to view their connections in a popup panel. Click on any connection to navigate directly to that linked node.

## Features

- **Double-click** on any node in canvas view to open the connections panel
- View **incoming** and **outgoing** connections separately
- See **edge labels** if they exist
- **Click on a connection** to navigate to that node and center the view
- Use the command palette: `Show connections for selected node`

## Installation

### Manual Installation (Recommended for local use)

1. Navigate to your Obsidian vault's plugins folder:
   ```
   YourVault/.obsidian/plugins/
   ```

2. Create a new folder called `connection-navigator`:
   ```
   YourVault/.obsidian/plugins/connection-navigator/
   ```

3. Copy these files into that folder:
   - `manifest.json`
   - `main.js`
   - `styles.css` (optional - styles are included in main.js)

4. Restart Obsidian or reload (Ctrl/Cmd + R)

5. Go to Settings → Community Plugins → Enable "Connection Navigator"

### Alternative: Using BRAT (Beta Reviewers Auto-update Tester)

If you want to install from GitHub:
1. Install the BRAT plugin
2. Add this plugin repository URL
3. Enable the plugin

## Usage

1. Open a canvas file in Obsidian
2. **Double-click** on any node to see its connections
3. The popup shows:
   - Current node preview
   - Total connection count
   - Incoming connections (← blue)
   - Outgoing connections (→ orange)
   - Edge labels if present
4. **Click any connection** to jump to that node

### Keyboard Shortcut

You can also use the command palette (Ctrl/Cmd + P):
- Select a node on the canvas
- Open command palette
- Search for "Show connections for selected node"

## Customization

The plugin uses Obsidian's CSS variables so it automatically matches your theme. If you want to customize the appearance, you can add custom CSS in your vault's `snippets` folder.

## Compatibility

- Requires Obsidian v1.0.0 or higher
- Works with the native Canvas plugin

## Development

This plugin is built with vanilla JavaScript (no build step required). The main files are:

- `manifest.json` - Plugin metadata
- `main.js` - All plugin logic
- `styles.css` - Styling (also embedded in main.js)

## License

MIT License - Feel free to modify and share!

## Credits

Inspired by the canvas viewer prototype with connection navigation features.
